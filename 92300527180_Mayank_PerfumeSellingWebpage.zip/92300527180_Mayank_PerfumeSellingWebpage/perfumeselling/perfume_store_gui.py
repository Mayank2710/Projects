import tkinter as tk
from tkinter import messagebox, ttk
from PIL import Image, ImageTk

# Product list with image paths
products = [
    {"name": "Floral Bliss", "price": 3799, "image": "/Users/mayank/Desktop/python7180/fb.jpg"},
    {"name": "Citrus Charm", "price": 3299, "image": "/Users/mayank/Desktop/python7180/cc.jpg"},
    {"name": "Mystic Oud", "price": 4599, "image": "/Users/mayank/Desktop/python7180/mo.jpg"},
    {"name": "Wild Vetiver", "price": 4999, "image": "/Users/mayank/Desktop/python7180/wv.jpg"},
    {"name": "Smoky Agarwood", "price": 5850, "image": "/Users/mayank/Desktop/python7180/sag.jpg"},
    {"name": "Ocean Breeze", "price": 2899, "image": "/Users/mayank/Desktop/python7180/ob.jpg"},
    {"name": "Vanilla Sky", "price": 4025, "image": "/Users/mayank/Desktop/python7180/vs.jpg"},
    {"name": "Spiced Amber", "price": 4310, "image": "/Users/mayank/Desktop/python7180/sa.jpg"},
    {"name": "Jasmine Light", "price": 3300, "image": "/Users/mayank/Desktop/python7180/jg.jpg"},
]

cart = []

def add_to_cart(product):
    cart.append(product)
    messagebox.showinfo("Added to Cart", f"{product['name']} has been added to your cart!")

def view_cart():
    cart_window = tk.Toplevel(root)
    cart_window.title("🛒 Your Shopping Cart")
    cart_window.geometry("520x500")
    cart_window.configure(bg="white")

    tk.Label(
        cart_window, text="🛒 Cart Summary", font=("Helvetica Neue", 20, "bold"),
        fg="#880e4f", bg="white"
    ).pack(pady=15)

    if not cart:
        tk.Label(
            cart_window, text="Your cart is currently empty.",
            font=("Segoe UI", 12), bg="white", fg="gray"
        ).pack(pady=30)
        ttk.Button(cart_window, text="Close", command=cart_window.destroy).pack(pady=10)
        return

    columns = ("Name", "Price")
    tree = ttk.Treeview(cart_window, columns=columns, show="headings", height=10)
    tree.heading("Name", text="Product")
    tree.heading("Price", text="Price")
    tree.column("Name", width=300, anchor="w")
    tree.column("Price", anchor="center")

    style = ttk.Style()
    style.configure("Treeview.Heading", font=("Segoe UI", 10, "bold"))
    style.configure("Treeview", font=("Segoe UI", 10), rowheight=30)

    total = 0
    for item in cart:
        tree.insert("", tk.END, values=(item["name"], f"₹{item['price']:.2f}"))
        total += item['price']

    tree.pack(padx=20, pady=10, fill="both", expand=True)

    tk.Label(
        cart_window, text=f"Total: ₹{total:.2f}",
        font=("Segoe UI", 12, "bold"), fg="#4a148c", bg="white"
    ).pack(pady=(10, 5))

    button_frame = tk.Frame(cart_window, bg="white")
    button_frame.pack(pady=10)

    def clear_cart():
        cart.clear()
        cart_window.destroy()
        messagebox.showinfo("Cart Cleared", "All items have been removed from your cart.")

    ttk.Button(button_frame, text="✅ Checkout", command=cart_window.destroy, style="Custom.TButton").grid(row=0, column=0, padx=10)
    ttk.Button(button_frame, text="🗑️ Clear Cart", command=clear_cart, style="Custom.TButton").grid(row=0, column=1, padx=10)

# Main window
root = tk.Tk()
root.title("🌸 Perfume Store 🌸")
root.geometry("1024x768")
root.configure(bg="white")

# Header
tk.Label(
    root,
    text="🌸 Perfume Store 🌸",
    font=("Helvetica Neue", 24, "bold"),
    bg="white",
    fg="#880e4f"
).pack(pady=20)

# Centering frame inside a canvas
canvas = tk.Canvas(root, bg="white", highlightthickness=0)
scrollbar = tk.Scrollbar(root, orient="vertical", command=canvas.yview)
canvas.configure(yscrollcommand=scrollbar.set)

scrollbar.pack(side="right", fill="y")
canvas.pack(side="left", fill="both", expand=True)

outer_frame = tk.Frame(canvas, bg="white")
canvas.create_window((0, 0), window=outer_frame, anchor="n", width=950)

frame = tk.Frame(outer_frame, bg="white")
frame.pack(anchor="center")

def on_frame_configure(event):
    canvas.configure(scrollregion=canvas.bbox("all"))

outer_frame.bind("<Configure>", on_frame_configure)

columns = 3
for col in range(columns):
    frame.grid_columnconfigure(col, weight=1, uniform="equal")

rows = len(products) // columns + (1 if len(products) % columns else 0)
for row in range(rows):
    frame.grid_rowconfigure(row, weight=1, uniform="equal")

style = ttk.Style()
style.configure("Custom.TButton", font=("Segoe UI", 12), padding=8)
style.map("Custom.TButton", background=[('active', '#ce93d8')])

for idx, product in enumerate(products):
    row = idx // columns
    col = idx % columns

    card = tk.Frame(frame, bg="white", bd=1, relief="raised", width=300, height=340)
    card.grid(row=row, column=col, padx=25, pady=25, sticky="nsew")
    card.grid_propagate(False)

    try:
        img = Image.open(product["image"])
        img = img.resize((160, 160))
        img = ImageTk.PhotoImage(img)
    except Exception as e:
        img = None
        print(f"Error loading {product['image']}: {e}")

    if img:
        img_label = tk.Label(card, image=img, bg="white")
        img_label.image = img
        img_label.pack(pady=(10, 0))

    tk.Label(card, text=product["name"], bg="white", font=("Segoe UI", 10, "bold")).pack(pady=(10, 2))
    tk.Label(card, text=f"₹{product['price']:.2f}", bg="white", fg="#388e3c", font=("Segoe UI", 14, "bold")).pack()

    ttk.Button(card, text="➕ Add to Cart", style="Custom.TButton",
               command=lambda p=product: add_to_cart(p)).pack(pady=10)

# View cart button
tk.Button(
    root, text="🛒 View Cart", 
    bg="white",
    fg="black",
    font=("Segoe UI", 12, "bold"),
    command=view_cart
).pack(pady=15)

root.mainloop()
