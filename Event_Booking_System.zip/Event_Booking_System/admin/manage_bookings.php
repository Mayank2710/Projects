<?php
require_once '../db_connect.php';

// Security: Check if user is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// Handle booking status update
if (isset($_GET['action']) && isset($_GET['booking_id'])) {
    $action = $_GET['action'];
    $booking_id = $_GET['booking_id'];
    $new_status = '';

    if ($action == 'approve') {
        $new_status = 'approved';
    } elseif ($action == 'reject') {
        $new_status = 'rejected';
    }

    if (!empty($new_status)) {
        $sql = "UPDATE bookings SET status = ? WHERE id = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "si", $new_status, $booking_id);
        mysqli_stmt_execute($stmt);
        header("Location: manage_bookings.php"); // Redirect to avoid re-processing on refresh
        exit();
    }
}

// Fetch all bookings with user and event details
$sql = "SELECT b.id, u.username, e.event_name, e.event_date, b.status 
        FROM bookings b
        JOIN users u ON b.user_id = u.id
        JOIN events e ON b.event_id = e.id
        ORDER BY e.event_date DESC";
$bookings_result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Bookings</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>
<div class="container">
    <div class="header">
        <h1>Manage Bookings</h1>
        <p><a href="dashboard.php">Back to Dashboard</a> | <a href="../logout.php">Logout</a></p>
    </div>

    <div class="content">
        <h2>All User Bookings</h2>
        <table>
            <thead>
                <tr>
                    <th>Username</th>
                    <th>Event Name</th>
                    <th>Event Date</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($booking = mysqli_fetch_assoc($bookings_result)): ?>
                <tr>
                    <td><?php echo htmlspecialchars($booking['username']); ?></td>
                    <td><?php echo htmlspecialchars($booking['event_name']); ?></td>
                    <td><?php echo date("d M Y", strtotime($booking['event_date'])); ?></td>
                    <td><span class="status-<?php echo $booking['status']; ?>"><?php echo ucfirst($booking['status']); ?></span></td>
                    <td>
                        <?php if ($booking['status'] == 'pending'): ?>
                            <a href="manage_bookings.php?action=approve&booking_id=<?php echo $booking['id']; ?>" class="btn">Approve</a>
                            <a href="manage_bookings.php?action=reject&booking_id=<?php echo $booking['id']; ?>" class="btn btn-danger">Reject</a>
                        <?php else: ?>
                            <span>-</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>