<?php
require_once '../db_connect.php';

// Security: Check if user is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

$message = '';

// Handle Add Holiday
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_holiday'])) {
    $holiday_name = trim($_POST['holiday_name']);
    $holiday_date = $_POST['holiday_date'];

    if (!empty($holiday_name) && !empty($holiday_date)) {
        $sql = "INSERT INTO holidays (holiday_name, holiday_date) VALUES (?, ?)";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "ss", $holiday_name, $holiday_date);
        if (mysqli_stmt_execute($stmt)) {
            $message = "<p class='success'>Holiday added successfully!</p>";
        } else {
            $message = "<p class='error'>Error: Could not add holiday. Date might already be taken.</p>";
        }
    }
}

// Handle Delete Holiday
if (isset($_GET['delete_id'])) {
    $holiday_id = $_GET['delete_id'];
    $sql = "DELETE FROM holidays WHERE id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $holiday_id);
    mysqli_stmt_execute($stmt);
    $message = "<p class='success'>Holiday deleted successfully!</p>";
}

// Fetch all holidays
$holidays_result = mysqli_query($conn, "SELECT * FROM holidays ORDER BY holiday_date DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Holidays</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>
<div class="container">
    <div class="header">
        <h1>Manage Holidays</h1>
        <p><a href="dashboard.php">Back to Dashboard</a> | <a href="../logout.php">Logout</a></p>
    </div>

    <?php echo $message; ?>

    <div class="form-container">
        <h2>Add New Holiday</h2>
        <form method="post">
            <label for="holiday_name">Holiday Name:</label>
            <input type="text" id="holiday_name" name="holiday_name" required>
            
            <label for="holiday_date">Holiday Date:</label>
            <input type="date" id="holiday_date" name="holiday_date" required>
            
            <button type="submit" name="add_holiday">Add Holiday</button>
        </form>
    </div>

    <div class="content">
        <h2>Existing Holidays</h2>
        <table>
            <thead>
                <tr>
                    <th>Holiday Name</th>
                    <th>Date</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($holiday = mysqli_fetch_assoc($holidays_result)): ?>
                <tr>
                    <td><?php echo htmlspecialchars($holiday['holiday_name']); ?></td>
                    <td><?php echo date("d M Y", strtotime($holiday['holiday_date'])); ?></td>
                    <td>
                        <a href="manage_holidays.php?delete_id=<?php echo $holiday['id']; ?>" class="btn btn-danger" onclick="return confirm('Are you sure?');">Delete</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>