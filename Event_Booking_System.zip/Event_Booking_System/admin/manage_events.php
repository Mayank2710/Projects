<?php
require_once '../db_connect.php';

// Security: Check if the user is logged in and is an admin.
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

$message = '';

// Handle Add Event POST request
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_event'])) {
    $event_name = trim($_POST['event_name']);
    $event_description = trim($_POST['event_description']);
    $event_date = $_POST['event_date'];

    if (!empty($event_name) && !empty($event_date)) {
        $sql = "INSERT INTO events (event_name, event_description, event_date) VALUES (?, ?, ?)";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "sss", $event_name, $event_description, $event_date);
        if (mysqli_stmt_execute($stmt)) {
            $message = "<p class='success'>Event added successfully!</p>";
        } else {
            $message = "<p class='error'>Error: Could not add event. The date might already be taken.</p>";
        }
        mysqli_stmt_close($stmt);
    } else {
        $message = "<p class='error'>Event name and date are required.</p>";
    }
}

// Handle Delete Event GET request
if (isset($_GET['delete_id'])) {
    $event_id = $_GET['delete_id'];
    $sql = "DELETE FROM events WHERE id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $event_id);
    if (mysqli_stmt_execute($stmt)) {
        $message = "<p class='success'>Event deleted successfully!</p>";
    } else {
        $message = "<p class='error'>Error: Could not delete event.</p>";
    }
    mysqli_stmt_close($stmt);
}

// Fetch all events to display
$events_result = mysqli_query($conn, "SELECT * FROM events ORDER BY event_date DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Events</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>
<div class="container">
    <div class="header">
        <h1>Manage Events</h1>
        <p><a href="dashboard.php">Back to Dashboard</a> | <a href="../logout.php">Logout</a></p>
    </div>

    <?php echo $message; ?>

    <div class="form-container">
        <h2>Add New Event</h2>
        <form method="post">
            <label for="event_name">Event Name:</label>
            <input type="text" id="event_name" name="event_name" required>

            <label for="event_description">Description:</label>
            <textarea id="event_description" name="event_description" rows="3"></textarea>

            <label for="event_date">Event Date:</label>
            <input type="date" id="event_date" name="event_date" required>

            <button type="submit" name="add_event">Add Event</button>
        </form>
    </div>

    <div class="content">
        <h2>Existing Events</h2>
        <table>
            <thead>
                <tr>
                    <th>Event Name</th>
                    <th>Description</th>
                    <th>Date</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($event = mysqli_fetch_assoc($events_result)): ?>
                <tr>
                    <td><?php echo htmlspecialchars($event['event_name']); ?></td>
                    <td><?php echo htmlspecialchars($event['event_description']); ?></td>
                    <td><?php echo date("d M Y", strtotime($event['event_date'])); ?></td>
                    <td>
                        <a href="manage_events.php?delete_id=<?php echo $event['id']; ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this event?');">Delete</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>