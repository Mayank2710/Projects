<?php
require_once '../db_connect.php';

// Security: Check if user is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

$message = '';

// --- NEW: HANDLE DELETE REQUEST ---
if (isset($_GET['delete_id'])) {
    $user_id_to_delete = $_GET['delete_id'];

    // Safety check: Do not allow the main admin account to be deleted
    $check_sql = "SELECT username FROM users WHERE id = ?";
    $stmt_check = mysqli_prepare($conn, $check_sql);
    mysqli_stmt_bind_param($stmt_check, "i", $user_id_to_delete);
    mysqli_stmt_execute($stmt_check);
    $result_check = mysqli_stmt_get_result($stmt_check);
    $user_to_delete = mysqli_fetch_assoc($result_check);

    if ($user_to_delete && $user_to_delete['username'] === 'admin') {
        $message = "<p class='error'>Error: The main admin account cannot be deleted.</p>";
    } else {
        // Proceed with deletion
        $delete_sql = "DELETE FROM users WHERE id = ?";
        $stmt_delete = mysqli_prepare($conn, $delete_sql);
        mysqli_stmt_bind_param($stmt_delete, "i", $user_id_to_delete);
        if (mysqli_stmt_execute($stmt_delete)) {
            $message = "<p class='success'>User deleted successfully!</p>";
        } else {
            $message = "<p class='error'>Error: Could not delete user.</p>";
        }
    }
}

// Handle Add User
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_user'])) {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $role = $_POST['role'];

    if (!empty($username) && !empty($password) && !empty($role)) {
        $sql = "INSERT INTO users (username, password, role) VALUES (?, ?, ?)";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "sss", $username, $password, $role);
        if (mysqli_stmt_execute($stmt)) {
            $message = "<p class='success'>User created successfully!</p>";
        } else {
            $message = "<p class='error'>Error: Username may already exist.</p>";
        }
    } else {
        $message = "<p class='error'>All fields are required.</p>";
    }
}

// Fetch all users to display
$users_result = mysqli_query($conn, "SELECT id, username, role, created_at FROM users");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Users</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>
<div class="container">
    <div class="header">
        <h1>Manage Users</h1>
        <p><a href="dashboard.php">Back to Dashboard</a> | <a href="../logout.php">Logout</a></p>
    </div>

    <?php echo $message; ?>

    <div class="form-container">
        <h2>Create New User</h2>
        <form method="post">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
            <label for="role">Role:</label>
            <select id="role" name="role">
                <option value="user">User</option>
                <option value="admin">Admin</option>
            </select>
            <button type="submit" name="add_user">Create User</button>
        </form>
    </div>

    <div class="content">
        <h2>Existing Users</h2>
        <table>
            <thead>
                <tr>
                    <th>Username</th>
                    <th>Role</th>
                    <th>Date Created</th>
                    <th>Action</th> </tr>
            </thead>
            <tbody>
                <?php while ($user = mysqli_fetch_assoc($users_result)): ?>
                <tr>
                    <td><?php echo htmlspecialchars($user['username']); ?></td>
                    <td><?php echo ucfirst($user['role']); ?></td>
                    <td><?php echo date("d M Y", strtotime($user['created_at'])); ?></td>
                    <td>
                        <?php if ($user['username'] !== 'admin'): ?>
                            <a href="manage_users.php?delete_id=<?php echo $user['id']; ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this user?');">Delete</a>
                        <?php else: ?>
                            <span>-</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>