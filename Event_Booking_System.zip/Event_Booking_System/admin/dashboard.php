<?php
require_once '../db_connect.php';

// Security check
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>
<div class="container">
    <div class="header">
        <h1>Admin Dashboard</h1>
        <p>Welcome, <strong><?php echo htmlspecialchars($_SESSION['username']); ?></strong>!
           <a href="../logout.php">Logout</a></p>
    </div>
    <div class="nav">
        <a href="manage_events.php">Manage Events</a>
        <a href="manage_bookings.php">Manage Bookings</a>
        <a href="manage_holidays.php">Manage Holidays</a>
        <a href="manage_users.php">Manage Users</a>
    </div>
    <div class="content">
        <h2>System Overview</h2>
        <p>Use the navigation links above to manage the system.</p>
    </div>
</div>
</body>
</html>