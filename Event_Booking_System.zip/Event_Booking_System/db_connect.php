<?php
// --- Database Connection ---
$db_host = 'localhost';
$db_user = 'root';     // Your database username
$db_pass = '';         // Your database password
$db_name = 'event';

// Create a connection
$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

// Check the connection
if (!$conn) {
     die("Connection failed: " . mysqli_connect_error());
}

// --- Start Session ---
// This is needed for login management on every page.
session_start();
?>
