<?php
require_once '../db_connect.php';

// Security: Check if a user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

$message = '';
$user_id = $_SESSION['user_id'];

// Handle a booking request from a GET parameter
if (isset($_GET['book_event_id'])) {
    $event_id = $_GET['book_event_id'];

    // 1. Check if the user has already booked this event
    $check_sql = "SELECT id FROM bookings WHERE user_id = ? AND event_id = ?";
    $stmt = mysqli_prepare($conn, $check_sql);
    mysqli_stmt_bind_param($stmt, "ii", $user_id, $event_id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_store_result($stmt);

    if (mysqli_stmt_num_rows($stmt) == 0) {
        // 2. If not booked, insert the new booking as 'pending'
        $insert_sql = "INSERT INTO bookings (user_id, event_id, status) VALUES (?, ?, 'pending')";
        $stmt_insert = mysqli_prepare($conn, $insert_sql);
        mysqli_stmt_bind_param($stmt_insert, "ii", $user_id, $event_id);
        if (mysqli_stmt_execute($stmt_insert)) {
            $message = "<p class='success'>Booking request sent! Check 'My Bookings' for status.</p>";
        }
    } else {
        $message = "<p class='error'>You have already requested to book this event.</p>";
    }
    mysqli_stmt_close($stmt);
}

// Fetch all upcoming events and holidays to display in a single calendar view
$calendar_data = [];
$today = date("Y-m-d");

// Get events
$events_sql = "SELECT id, event_name, event_date FROM events WHERE event_date >= '$today'";
$events_result = mysqli_query($conn, $events_sql);
while($row = mysqli_fetch_assoc($events_result)) {
    $calendar_data[$row['event_date']][] = ['type' => 'event', 'name' => $row['event_name'], 'id' => $row['id']];
}

// Get holidays
$holidays_sql = "SELECT holiday_name, holiday_date FROM holidays WHERE holiday_date >= '$today'";
$holidays_result = mysqli_query($conn, $holidays_sql);
while($row = mysqli_fetch_assoc($holidays_result)) {
    $calendar_data[$row['holiday_date']][] = ['type' => 'holiday', 'name' => $row['holiday_name']];
}

// Sort the calendar data by date
ksort($calendar_data);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Dashboard</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>
<div class="container">
    <div class="header">
        <h1>User Dashboard</h1>
        <p>Welcome, <strong><?php echo htmlspecialchars($_SESSION['username']); ?></strong>! | <a href="../logout.php">Logout</a></p>
    </div>

    <div class="nav">
        <a href="my_bookings.php">My Bookings</a>
    </div>

    <?php echo $message; ?>

    <div class="content">
        <h2>Upcoming Events & Holidays</h2>
        <table>
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Details</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($calendar_data as $date => $items): ?>
                    <tr>
                        <td><?php echo date("D, d M Y", strtotime($date)); ?></td>
                        <td>
                            <?php foreach ($items as $item): ?>
                                <?php if ($item['type'] == 'event'): ?>
                                    <strong>Event:</strong> <?php echo htmlspecialchars($item['name']); ?><br>
                                <?php else: ?>
                                    <span class="holiday">Holiday: <?php echo htmlspecialchars($item['name']); ?></span><br>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </td>
                        <td>
                            <?php foreach ($items as $item): ?>
                                <?php if ($item['type'] == 'event'): ?>
                                     <a href="dashboard.php?book_event_id=<?php echo $item['id']; ?>" class="btn">Book Now</a>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                 <?php if (empty($calendar_data)): ?>
                    <tr>
                        <td colspan="3">No upcoming events or holidays.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>