library(ggplot2)

data <- read.csv("E:/R PROJECT/perfume_market_data.csv")

top_10 <- aggregate(Sales ~ Fragrance, data = data, sum)
top_10 <- top_10[order(-top_10$Sales), ][1:10, ]

top_10$Fragrance <- factor(top_10$Fragrance, levels = top_10$Fragrance)

ggplot(top_10, aes(x = Fragrance, y = Sales, group = 1)) +
  geom_line(color = "blue") +
  geom_point(color = "red", size = 2) +
  labs(title = "Top 10 Best-Selling Perfumes", x = "Fragrance", y = "Sales") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)
)
