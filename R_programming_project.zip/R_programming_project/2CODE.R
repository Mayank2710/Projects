data <- read.csv("E:/R PROJECT/perfume_market_data.csv")

data$PriceRange <- cut(data$Price, breaks = 5)

avg_rating <- aggregate(Customer_Rating ~ PriceRange, data = data, FUN = mean)

barplot(
  avg_rating$Customer_Rating,
  names.arg = avg_rating$PriceRange,
  col = "steelblue",
  main = "Average Customer Rating by Price Range",
  xlab = "Price Range",
  ylab = "Average Customer Rating",
  las = 2,          
  cex.names = 0.8    
)
