library(ggplot2)

data <- read.csv("E:/R PROJECT/perfume_market_data.csv")

print(
  ggplot(data, aes(x = Gender, fill = Fragrance)) +
    geom_bar() +
    labs(title = "Fragrance Popularity by Gender", x = "Gender", y = "Count") +
    theme_minimal() +
    theme(axis.text.x = element_text(angle = 0, hjust = 0.5))
)
