data <- read.csv("E:/R PROJECT/perfume_market_data.csv")

data$Price_Group <- cut(
  data$Price,
  breaks = seq(0, ceiling(max(data$Price)), by = 10),
  include.lowest = TRUE
)

library(ggplot2)

ggplot(data, aes(x = Price_Group)) +
  geom_bar(fill = "#FFCCCC", color = "black") +
  labs(title = "Perfume Count by Price Range", x = "Price Range", y = "Count") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))
