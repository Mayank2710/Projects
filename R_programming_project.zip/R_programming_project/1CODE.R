library(plotrix)

data <- read.csv("E:/R PROJECT/perfume_market_data.csv")

sales_by_brand <- aggregate(Sales ~ Brand, data = data, sum)

total_sales <- sum(sales_by_brand$Sales)
sales_percent <- round(100 * sales_by_brand$Sales / total_sales, 1)
labels <- paste(sales_by_brand$Brand, "-", sales_percent, "%")

pie3D(
  sales_by_brand$Sales,
  labels = labels,
  explode = 0.1,                     
  col = rainbow(length(labels)),
  main = "3D Sales Performance by Brand",
  labelcex = 0.8
)
